package empsys;


	import java.sql.SQLException;
	import java.sql.Statement;
	import java.sql.ResultSet;
	import java.sql.PreparedStatement;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.util.ArrayList;
	import java.util.List;

	public class EmpDAOImpl implements EmpDAO {
		
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payroll", "root", "yagops1234");

	    public EmpDAOImpl() throws SQLException {
//	    	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/payroll", "root", "yagops1234");
	    }

	    private double calculateNetSalary(EmpDTO emp) {
	        return emp.getBasicSalary() + emp.getAllowance() - emp.getDeduction();
	    }

	    @Override
	    public void addEmployee(EmpDTO emp) {
	    	String sql = "INSERT INTO employee (emp_id, emp_name, basic_salary, allowance, deduction, net_salary) VALUES (?, ?, ?, ?, ?, ?)";

	        try {
	           
				PreparedStatement ps = con.prepareStatement(sql);
	            ps.setInt(1, emp.getEmpId());
	            ps.setString(2, emp.getEmpName());
	            ps.setDouble(3, emp.getBasicSalary());
	            ps.setDouble(4, emp.getAllowance());
	            ps.setDouble(5, emp.getDeduction());
	            ps.setDouble(6, emp.getNetSalary());
	            ps.executeUpdate();
	            emp.setNetSalary(calculateNetSalary(emp));
	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	   
	    public void updateEmployee(EmpDTO emp) {

	        String sql = "UPDATE employee SET emp_name=?, basic_salary=?, allowance=?, deduction=?, net_salary=? WHERE emp_id=?";

	        try {
	            // 1. Calculate net salary first
	            double netSalary = calculateNetSalary(emp);
	            emp.setNetSalary(netSalary);

	            PreparedStatement ps = con.prepareStatement(sql);

	            // 2. Correct parameter order
	            ps.setString(1, emp.getEmpName());
	            ps.setDouble(2, emp.getBasicSalary());
	            ps.setDouble(3, emp.getAllowance());
	            ps.setDouble(4, emp.getDeduction());
	            ps.setDouble(5, emp.getNetSalary()); // net_salary
	            ps.setInt(6, emp.getEmpId());        // emp_id

	            // 3. Execute update
	            ps.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }


	    @Override
	    public void deleteEmployee(int empId) {
	        String sql = "DELETE FROM employee WHERE emp_id=?";
	        try {
	            PreparedStatement ps = con.prepareStatement(sql);
	            ps.setInt(1, empId);
	            ps.executeUpdate();
	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public List<EmpDTO> getAllEmployees() {
	        List<EmpDTO> list = new ArrayList<>();
	        String sql = "SELECT * FROM employee";
	        try {
	            Statement st=con.createStatement();
	            ResultSet rs = st.executeQuery(sql);

	            while(rs.next()) {
	                EmpDTO emp = new EmpDTO();
	                emp.setEmpId(rs.getInt("emp_id"));
	                emp.setEmpName(rs.getString("emp_name"));
	                emp.setBasicSalary(rs.getDouble("basic_salary"));
	                emp.setAllowance(rs.getDouble("allowance"));
	                emp.setDeduction(rs.getDouble("deduction"));
	                emp.setNetSalary(calculateNetSalary(emp));
	                list.add(emp);
	            }

	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	        return list;
	    }
	}



