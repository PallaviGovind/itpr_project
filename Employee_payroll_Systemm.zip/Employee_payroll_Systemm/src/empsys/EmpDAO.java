package empsys;



	import java.util.List;

	public interface EmpDAO {

	    void addEmployee(EmpDTO emp);

	    void updateEmployee(EmpDTO emp);

	    void deleteEmployee(int empId);

	    List<EmpDTO> getAllEmployees();
	}








