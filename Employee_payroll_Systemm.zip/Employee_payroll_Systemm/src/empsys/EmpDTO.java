package empsys;

public class EmpDTO {


	    private int empId;
	    private String empName;
	    private double basicSalary;
	    private double allowance;
	    private double deduction;
	    private double netSalary; // optional, for display

	    // Default constructor
	    public EmpDTO() {}

	    // Parameterized constructor
	    public EmpDTO(int empId, String empName, double basicSalary, double allowance, double deduction) {
	        this.empId = empId;
	        this.empName = empName;
	        this.basicSalary = basicSalary;
	        this.allowance = allowance;
	        this.deduction = deduction;
	        this.netSalary = basicSalary + allowance - deduction;
	    }

	    // Getters and setters
	    public int getEmpId() { return empId; }
	    public void setEmpId(int empId) { this.empId = empId; }

	    public String getEmpName() { return empName; }
	    public void setEmpName(String empName) { this.empName = empName; }

	    public double getBasicSalary() { return basicSalary; }
	    public void setBasicSalary(double basicSalary) { this.basicSalary = basicSalary; }

	    public double getAllowance() { return allowance; }
	    public void setAllowance(double allowance) { this.allowance = allowance; }

	    public double getDeduction() { return deduction; }
	    public void setDeduction(double deduction) { this.deduction = deduction; }

	    public double getNetSalary() { return netSalary; }
	    public void setNetSalary(double netSalary) { this.netSalary = netSalary; }
	}





