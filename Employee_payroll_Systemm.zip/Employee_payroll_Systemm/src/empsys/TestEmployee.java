package empsys;

	import java.util.Scanner;
	import java.sql.SQLException;
	import java.util.List;

	public class TestEmployee {

		public static void main(String[] args) {
		    try {
		        EmpDAO dao = new EmpDAOImpl();
		        Scanner sc = new Scanner(System.in);
		        boolean exit = false;

		        while (!exit) {
		            System.out.println("\n=== EMPLOYEE MENU ===");
		            System.out.println("1. Add Employee");
		            System.out.println("2. Update Employee");
		            System.out.println("3. Delete Employee");
		            System.out.println("4. Show All Employees");
		            System.out.println("5. Exit");
		            System.out.print("Enter your choice: ");

		            int choice = sc.nextInt();
		            sc.nextLine();
		         switch(choice)
		         {
		        	case 1: // Add
                    System.out.print("Enter Employee ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Basic Salary: ");
                    double basic = sc.nextDouble();
                    System.out.print("Enter Allowance: ");
                    double allowance = sc.nextDouble();
                    System.out.print("Enter Deduction: ");
                    double deduction = sc.nextDouble();

                    EmpDTO emp = new EmpDTO(id, name, basic, allowance, deduction);
                    dao.addEmployee(emp);
                    break;

                case 2: // Update
                    System.out.print("Enter Employee ID to update: ");
                    id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter new Name: ");
                    name = sc.nextLine();
                    System.out.print("Enter new Basic Salary: ");
                    basic = sc.nextDouble();
                    System.out.print("Enter new Allowance: ");
                    allowance = sc.nextDouble();
                    System.out.print("Enter new Deduction: ");
                    deduction = sc.nextDouble();

                    emp = new EmpDTO(id, name, basic, allowance, deduction);
                    dao.updateEmployee(emp);
                    break;

                case 3: // Delete
                    System.out.print("Enter Employee ID to delete: ");
                    id = sc.nextInt();
                    dao.deleteEmployee(id);
                    break;

                case 4: // Show all
                    List<EmpDTO> list = dao.getAllEmployees();
                    System.out.println("All Employees:");
                    for(EmpDTO e : list) {
                        System.out.println("Employee ID: " + e.getEmpId());
                        System.out.println("Employee Name: " + e.getEmpName());
                        System.out.println("Basic Salary: " + e.getBasicSalary());
                        System.out.println("Allowance: " + e.getAllowance());
                        System.out.println("Deduction: " + e.getDeduction());
                        System.out.println("Net Salary: " + e.getNetSalary());
                        System.out.println();
                    }
                    break;

                case 5:
                    exit = true;
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        

		           
		            
		        }
		    } catch (SQLException e) {
		        System.out.println("Database error occurred!");
		        e.printStackTrace();
		    }
		   
		}
		
		}